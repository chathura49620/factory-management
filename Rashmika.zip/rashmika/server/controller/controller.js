// var category = require('./category.controller');
exports.category = require("./category.controller");
exports.materialCode = require("./materialcode.controller");
exports.productcode = require("./productCode.controller");
exports.factoryDetails = require("./factoryDetails.controller");
exports.userRole = require("./userRole.controller");
exports.leaveDetails = require("./employeeLeave.controller");
exports.assignmentDetails = require("./employeeassignment.controller");
exports.newProductionRoundDetails = require("./newProductionRound.controller");
exports.orderDetails = require("./orderDetails.controller");
exports.login = require("./login.controller");
exports.items = require("./item.controller");

exports.billType = require("./billType.controller");
exports.bills = require("./bills.controller");
