const mongoose = require('mongoose');
var category = require('./category.model');
var materialcode = require('./materialcode.model');
var factoryIntialDetails = require('./factoryIntialDetails.model');
var userRole = require('./userRole.model');
var employeeassignment = require('./employeeassignment.model');
